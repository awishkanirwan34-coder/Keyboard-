# LankaKeys - Native Android Sinhala & English Keyboard

A production-oriented Android Input Method Service (IME) app built with Kotlin and Jetpack Compose.

## How to Build the APK / AAB

### 1. Requirements
- Android Studio Ladybug (2024.2.1+) or newer
- JDK 17
- Android SDK Platform 35

### 2. Opening in Android Studio
1. Unzip this directory.
2. Open Android Studio -> **File** -> **Open...** -> select the `LankaKeys` directory.
3. Allow Gradle to sync dependencies automatically.

### 3. Generate Debug APK (for instant testing on your phone):
Run in terminal:
```bash
./gradlew assembleDebug
```
The APK will be generated at:
`app/build/outputs/apk/debug/app-debug.apk`

To install directly to a connected Android phone:
```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

### 4. Generate Signed Android App Bundle (.aab) for Google Play:
```bash
./gradlew bundleRelease
```
The bundle will be located at:
`app/build/outputs/bundle/release/app-release.aab`
