-keep public class com.lankakeys.keyboard.LankaKeysIME extends android.inputmethodservice.InputMethodService {
    public <init>();
}
-keep public class com.lankakeys.keyboard.ui.MainActivity extends androidx.activity.ComponentActivity {
    public <init>();
}
-keepclassmembers class com.lankakeys.keyboard.engine.** { *; }
-keepclassmembers class com.lankakeys.keyboard.theme.** { *; }
-keepattributes *Annotation*
-dontwarn androidx.compose.**
